# Top-down miner sprite pack for LibGDX

## Contents
- `miner.png` + `miner.atlas` — 2x2 LibGDX TextureAtlas.
- `miner_up.png`, `miner_right.png`, `miner_down.png`, `miner_left.png` — individual transparent PNG frames.
- `LibGDX_Example.java.txt` — minimal TextureAtlas/SpriteBatch example.

## Atlas regions
- `miner_up`
- `miner_right`
- `miner_down`
- `miner_left`

## Import
Copy `miner.png` and `miner.atlas` into your LibGDX assets folder, for example:
`assets/sprites/`

Load with:
`new TextureAtlas(Gdx.files.internal("sprites/miner.atlas"))`

All frames are 384x384 RGBA PNGs with transparent padding and a shared center alignment.
The supplied art contains one static pose per direction; walk/mining animation frames are not included yet.
